package com.example.demo2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    public static Scene login;
    public static Scene Recipe;
    public static Scene category;
    public static Scene Home;
    public static Scene SignIn;
    public static Scene Exit;
    public static Scene Success;
    public static Scene Sample;
    public static Scene Sample2;
    public static Scene Veg;
    public static Scene Noodles;

    public static Stage mystage;
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Login.fxml"));
        FXMLLoader RecipefxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Recipe.fxml"));
        FXMLLoader categoryfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Category.fxml"));
        FXMLLoader homefxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Home.fxml"));
        FXMLLoader SignInfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("SignIn.fxml"));
        FXMLLoader exitfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("exit.fxml"));
        FXMLLoader SuccessfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Success.fxml"));
        FXMLLoader SamplefxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Sample.fxml"));
        FXMLLoader Sample2fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Sample2.fxml"));
        FXMLLoader VegfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Veg.fxml"));
        FXMLLoader NoodlefxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Noodles.fxml"));



        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        Scene loginscene = new Scene(loginfxmlLoader.load(), 600, 400);
        Scene Recipescene = new Scene(RecipefxmlLoader.load(), 600, 400);
        Scene categoryscene = new Scene(categoryfxmlLoader.load(), 600, 400);
        Scene homescene = new Scene(homefxmlLoader.load(), 600, 400);
        Scene Signinscene = new Scene(SignInfxmlLoader.load(), 600, 400);
        Scene Exitscene = new Scene(exitfxmlLoader.load(), 600, 400);
        Scene Successscene = new Scene(SuccessfxmlLoader.load(), 600, 400);
        Scene Samplesscene = new Scene(SamplefxmlLoader.load(), 600, 400);
        Scene Sample2sscene = new Scene(Sample2fxmlLoader.load(), 600, 400);
        Scene Vegscene = new Scene(VegfxmlLoader.load(), 600, 400);
        Scene Noodlescene = new Scene(NoodlefxmlLoader.load(), 600, 400);

        mystage=stage;
        login=loginscene;
        Recipe=Recipescene;
        category=categoryscene;
        Home=homescene;
        SignIn=Signinscene;
        Exit=Exitscene;
        Success=Successscene;
        Sample=Samplesscene;
        Sample2=Sample2sscene;
        Veg=Vegscene;
        Noodles=Noodlescene;

        stage.setTitle("Login page");
        stage.setScene(loginscene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}