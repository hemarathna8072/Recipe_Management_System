package com.example.demo2;

import javafx.beans.Observable;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.*;
import java.sql.Connection;

public class HelloController {
    @FXML
    private Label welcomeText;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }


    @FXML

    protected void Login(){
       // HelloApplication.mystage.setScene(HelloApplication.Recipe);
      String dbUrl="jdbc:mysql://127.0.0.1:3306/recipe_management_system";
        String name=nameid.getText();
        String username=userid.getText();
        String password=passid.getText();
        System.out.println("My Fields are "+username+" "+password+" "+name);
        try {
            Connection connection = DriverManager.getConnection(dbUrl,"root","keerthikka@123");
            //String sql = "Insert into singup (userName, firstName, userPassword, userAddress) values (?, ?, ?, ?) ";
            String sql = "Insert into user values (?,?,?)";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,username);
            statement.setString(2,password);
            statement.setString(3,name);

            statement.execute();
            System.out.println("Inserted data into Login Table.");
            connection.close();

        }
        catch(Exception ex){
            System.out.println(ex);
        }
        HelloApplication.mystage.setScene(HelloApplication.Home);


    }


    @FXML
    protected void onExitBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.Exit);
    }

    @FXML
    protected void onSignInBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.SignIn);
    }
    @FXML
    private TextField Usernameid;
    @FXML
    private TextField passwordid;
    @FXML
    protected void onVerifyBtnClick(){


            String username1 = Usernameid.getText();
            String password1 = passwordid.getText();
            System.out.println("My details : " + username1 + " " + password1);
            String dburl = "jdbc:mysql://127.0.0.1:3306/recipe_management_system";

            try {
                Connection connection = DriverManager.getConnection(dburl, "root", "keerthikka@123");
                String sql = "SELECT * FROM user WHERE user_id = ? AND password = ?";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, username1);
                statement.setString(2, password1);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    // Authentication successful, user exists
//                    FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("my account1.fxml"));
//                    Parent root = loginfxmlLoader.load();
//
//                    Scene firstscene = new Scene(root);
//
//                    Stage stage = new Stage();
//                    stage.setTitle("Account");
//                    stage.setScene(firstscene);
//                    stage.show();
                    HelloApplication.mystage.setScene(HelloApplication.Success);

                } else {
                    labelid.setText("Invalid username or password.");
                }

                connection.close();
            } catch (Exception e) {
                System.out.println(e);
            }


    }
    @FXML
    protected void onViewUserBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.Sample);
    }
    @FXML
    protected void onViewCategoryBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.category);
    }
    @FXML
    protected void onVegBtnClick(){

        HelloApplication.mystage.setScene(HelloApplication.Veg);
    }
    @FXML
    protected void onNoodleBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.Noodles);
    }

    @FXML
    protected void onAddRecipeBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.Recipe);
    }
    @FXML
    protected void onViewRecipeBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.Sample2);
    }
    @FXML
    protected void onHomeBtnClick(){
        HelloApplication.mystage.setScene(HelloApplication.Home);
    }
    @FXML
    protected void Category(){
        String dbUrl="jdbc:mysql://127.0.0.1:3306/recipe_management_system";


        String username1=recnameid.getText();
        String username2=reccookingid.getText();
        String username3=recdesid.getText();
        String username4=recinstructorid.getText();

        System.out.println("My Fields are "+username1+" "+username2+" "+" "+username3+" "+username4);
        try {
            Connection connection = DriverManager.getConnection(dbUrl,"root","keerthikka@123");
            //String sql = "Insert into singup (userName, firstName, userPassword, userAddress) values (?, ?, ?, ?) ";
            String sql = "Insert into Recipe values (?,?,?,?)";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,username1);
            statement.setString(2,username2);
            statement.setString(3,username3);
            statement.setString(4,username4);

            statement.execute();
            System.out.println("Inserted data into Recipe Table.");
            connection.close();
            HelloApplication.mystage.setScene(HelloApplication.Home);
        }
        catch(Exception ex){
            System.out.println(ex);
        }



    }
    @FXML
    public TextField nameid;
    @FXML
    public Label labelid;
    @FXML
    public TextField userid;
    @FXML
    public TextField passid;
    @FXML
    public TextField recnameid;
    @FXML
    public TextField reccookingid;
    @FXML
    public TextField recdesid;
    @FXML
    public TextArea recinstructorid;
    @FXML
    private TableView<?> Tableuser;

    @FXML
    private TableColumn<?, ?> tpassid;

    @FXML
    private TableColumn<?, ?> tuserid;






//@FXML
//public ComboBox shownamesid;
//
//
//    @FXML
//    protected void loadnames(ActionEvent actionEvent){
//        try{
//            Class.forName("com.mysql.jdbc.Driver");
//            Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/Recipe_Management","root","Kiru@123");
//            ResultSet rs=con.createStatement().executeQuery("select *from names");
//            while(rs.next()){
//                Observable data= FXCollections.observableArrayList();
//                data.add((rs.getString(1)));
//
//
//            }
//            shownamesid.setItems(data);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//      }


}




