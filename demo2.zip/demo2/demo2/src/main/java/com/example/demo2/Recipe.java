package com.example.demo2;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Recipe {

    private final SimpleIntegerProperty recipeId;
    private final SimpleStringProperty name;
    private final SimpleStringProperty cookingTime;
    private final SimpleStringProperty instruction;

    public Recipe(int recipeId, String name, String cookingTime, String instruction) {
        this.recipeId = new SimpleIntegerProperty(recipeId);
        this.name = new SimpleStringProperty(name);
        this.cookingTime = new SimpleStringProperty(cookingTime);
        this.instruction = new SimpleStringProperty(instruction);
    }

    public int getRecipeId() {
        return recipeId.get();
    }

    public SimpleIntegerProperty recipeIdProperty() {
        return recipeId;
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public String getCookingTime() {
        return cookingTime.get();
    }

    public SimpleStringProperty cookingTimeProperty() {
        return cookingTime;
    }

    public String getInstruction() {
        return instruction.get();
    }

    public SimpleStringProperty instructionProperty() {
        return instruction;
    }
}

