package com.example.demo2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RecipeController {

    @FXML
    private TableView<Recipe> recipeTableView;

    @FXML
    private TableColumn<Recipe, Integer> recipeIdColumn;

    @FXML
    private TableColumn<Recipe, String> nameColumn;

    @FXML
    private TableColumn<Recipe, String> cookingTimeColumn;

    @FXML
    private TableColumn<Recipe, String> instructionColumn;

    public void initialize() {
        recipeIdColumn.setCellValueFactory(cellData -> cellData.getValue().recipeIdProperty().asObject());
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        cookingTimeColumn.setCellValueFactory(cellData -> cellData.getValue().cookingTimeProperty());
        instructionColumn.setCellValueFactory(cellData -> cellData.getValue().instructionProperty());
    }

    @FXML
    private void loadRecipeData() {
        ObservableList<Recipe> recipeList = FXCollections.observableArrayList();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/recipe_management_system", "root", "keerthikka@123")) {
            String sql = "SELECT recipe_id, name, cooking_time, instruction FROM recipe";
            try (PreparedStatement statement = connection.prepareStatement(sql);
                 ResultSet resultSet = statement.executeQuery()) {

                while (resultSet.next()) {
                    int recipeId = resultSet.getInt("recipe_id");
                    String name = resultSet.getString("name");
                    String cookingTime = resultSet.getString("cooking_time");
                    String instruction = resultSet.getString("instruction");
                    recipeList.add(new Recipe(recipeId, name, cookingTime, instruction));
                }

                recipeTableView.setItems(recipeList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @FXML
    protected void onBackBtn2Click(){
        HelloApplication.mystage.setScene(HelloApplication.Home);
    }
}

