package com.example.demo2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SampleController {

    @FXML
    private TableView<User> userTableView;

    @FXML
    private TableColumn<User, Integer> userIdColumn;

    @FXML
    private TableColumn<User, String> passwordColumn;

    public void initialize() {
        userIdColumn.setCellValueFactory(cellData -> cellData.getValue().userIdProperty().asObject());
        passwordColumn.setCellValueFactory(cellData -> cellData.getValue().passwordProperty());
    }

    @FXML
    private void loadData() {
        ObservableList<User> userList = FXCollections.observableArrayList();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/recipe_management_system", "root", "keerthikka@123")) {
            String sql = "SELECT user_id, name FROM user";
            try (PreparedStatement statement = connection.prepareStatement(sql);
                 ResultSet resultSet = statement.executeQuery()) {

                while (resultSet.next()) {
                    int userId = resultSet.getInt("user_id");
                    String password = resultSet.getString("name");
                    userList.add(new User(userId, password));
                }

                userTableView.setItems(userList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @FXML
    protected void onBackbtn1Click(){
        HelloApplication.mystage.setScene(HelloApplication.Home);
    }
}
